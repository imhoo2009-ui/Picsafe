const imageInput = document.getElementById("imageInput");
const processBtn = document.getElementById("processBtn");
const downloadBtn = document.getElementById("downloadBtn");
const statusText = document.getElementById("status");
const originalPreview = document.getElementById("originalPreview");
const protectedPreview = document.getElementById("protectedPreview");
const originalInfo = document.getElementById("originalInfo");
const protectedInfo = document.getElementById("protectedInfo");
const formatResult = document.getElementById("formatResult");
const dimensionsResult = document.getElementById("dimensionsResult");
const methodResult = document.getElementById("methodResult");
const hashResult = document.getElementById("hashResult");
const copyReportBtn = document.getElementById("copyReportBtn");

let selectedFile = null;
let originalImage = null;
let protectedUrl = null;
let reportText = "";

function setStatus(message) {
  statusText.textContent = message;
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function showImage(container, src, alt) {
  container.replaceChildren();
  const img = document.createElement("img");
  img.src = src;
  img.alt = alt;
  container.appendChild(img);
}

function clearProcessedResult() {
  if (protectedUrl) URL.revokeObjectURL(protectedUrl);
  protectedUrl = null;
  protectedPreview.replaceChildren(document.createTextNode("처리본 미리보기"));
  protectedInfo.textContent = "사진을 선택하면 처리할 수 있습니다.";
  downloadBtn.removeAttribute("href");
  downloadBtn.classList.add("disabled");
  downloadBtn.setAttribute("aria-disabled", "true");
  copyReportBtn.disabled = true;
  formatResult.textContent = "—";
  dimensionsResult.textContent = "—";
  methodResult.textContent = "—";
  hashResult.textContent = "—";
  reportText = "";
}

imageInput.addEventListener("change", () => {
  clearProcessedResult();
  selectedFile = imageInput.files && imageInput.files[0] ? imageInput.files[0] : null;
  originalImage = null;

  if (!selectedFile) {
    processBtn.disabled = true;
    setStatus("아직 사진을 선택하지 않았습니다.");
    originalPreview.replaceChildren(document.createTextNode("원본 미리보기"));
    originalInfo.textContent = "선택한 사진 정보가 여기에 표시됩니다.";
    return;
  }

  if (!selectedFile.type.startsWith("image/")) {
    processBtn.disabled = true;
    setStatus("이미지 파일을 선택해 주세요.");
    return;
  }

  const url = URL.createObjectURL(selectedFile);
  const img = new Image();
  img.onload = () => {
    originalImage = img;
    showImage(originalPreview, url, "사용자가 선택한 원본 사진");
    originalInfo.textContent = `${img.naturalWidth} × ${img.naturalHeight} px · ${formatBytes(selectedFile.size)}`;
    processBtn.disabled = false;
    setStatus("사진을 불러왔습니다. 보호 처리를 진행할 수 있습니다.");
  };
  img.onerror = () => {
    URL.revokeObjectURL(url);
    processBtn.disabled = true;
    setStatus("사진을 열 수 없습니다. 다른 이미지 파일을 선택해 주세요.");
  };
  img.src = url;
});

async function sha256Hex(arrayBuffer) {
  if (!crypto.subtle) {
    throw new Error("이 브라우저에서는 SHA-256 기능을 사용할 수 없습니다. HTTPS로 열린 GitHub Pages 주소에서 실행해 주세요.");
  }
  const digest = await crypto.subtle.digest("SHA-256", arrayBuffer);
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
}

// PNG chunk CRC-32 계산: PNG 파일의 메타데이터 청크를 올바르게 기록하기 위해 사용합니다.
function crc32(bytes) {
  let crc = -1;
  for (let i = 0; i < bytes.length; i++) {
    crc ^= bytes[i];
    for (let j = 0; j < 8; j++) {
      crc = (crc >>> 1) ^ ((crc & 1) ? 0xEDB88320 : 0);
    }
  }
  return (crc ^ -1) >>> 0;
}

function concatBytes(...arrays) {
  const total = arrays.reduce((sum, arr) => sum + arr.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const arr of arrays) {
    out.set(arr, offset);
    offset += arr.length;
  }
  return out;
}

function makePngTextChunk(keyword, value) {
  const encoder = new TextEncoder();
  const data = concatBytes(encoder.encode(keyword), new Uint8Array([0]), encoder.encode(value));
  const type = encoder.encode("tEXt");
  const chunkBody = concatBytes(type, data);
  const crc = crc32(chunkBody);
  const chunk = new Uint8Array(12 + data.length);
  const view = new DataView(chunk.buffer);
  view.setUint32(0, data.length, false);
  chunk.set(type, 4);
  chunk.set(data, 8);
  view.setUint32(8 + data.length, crc, false);
  return chunk;
}

function addTextChunksToPng(pngBytes, entries) {
  const signature = pngBytes.slice(0, 8);
  const view = new DataView(pngBytes.buffer, pngBytes.byteOffset, pngBytes.byteLength);
  let offset = 8;
  const chunks = [];
  let inserted = false;

  while (offset + 12 <= pngBytes.length) {
    const length = view.getUint32(offset, false);
    const end = offset + 12 + length;
    if (end > pngBytes.length) throw new Error("PNG 파일 구조를 읽을 수 없습니다.");

    const type = new TextDecoder().decode(pngBytes.slice(offset + 4, offset + 8));
    // 메타데이터는 IHDR 다음에 넣어 IDAT 이미지 데이터는 그대로 보존합니다.
    chunks.push(pngBytes.slice(offset, end));
    offset = end;

    if (type === "IHDR" && !inserted) {
      for (const [key, value] of entries) {
        chunks.push(makePngTextChunk(key, value));
      }
      inserted = true;
    }
    if (type === "IEND") break;
  }

  if (!inserted) throw new Error("올바른 PNG 파일을 만들지 못했습니다.");
  return new Blob([concatBytes(signature, ...chunks)], { type: "image/png" });
}

processBtn.addEventListener("click", async () => {
  if (!selectedFile || !originalImage) return;

  processBtn.disabled = true;
  copyReportBtn.disabled = true;
  setStatus("사진을 처리하고 파일 식별 정보를 계산하는 중입니다…");

  try {
    // 브라우저에서 PNG로 변환합니다. PNG 원본이면 디코딩된 픽셀을 재인코딩하고,
    // JPG/WEBP는 PNG 형식으로 변환합니다. 원본 파일 바이트와 메타데이터는 유지되지 않습니다.
    const canvas = document.createElement("canvas");
    canvas.width = originalImage.naturalWidth;
    canvas.height = originalImage.naturalHeight;
    const context = canvas.getContext("2d", { willReadFrequently: false });
    context.drawImage(originalImage, 0, 0);
    const basePngBlob = await new Promise((resolve, reject) => {
      canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error("PNG 변환에 실패했습니다.")), "image/png");
    });

    const baseBytes = await basePngBlob.arrayBuffer();
    const hash = await sha256Hex(baseBytes);
    const timestamp = new Date().toISOString();
    const finalBlob = addTextChunksToPng(new Uint8Array(baseBytes), [
      ["PicSafe_notice", "PicSafe educational prototype; metadata is not a deepfake-blocking mechanism."],
      ["PicSafe_SHA256", hash],
      ["PicSafe_processed_utc", timestamp]
    ]);

    if (protectedUrl) URL.revokeObjectURL(protectedUrl);
    protectedUrl = URL.createObjectURL(finalBlob);
    showImage(protectedPreview, protectedUrl, "PicSafe 메타데이터 처리본");
    protectedInfo.textContent = `${originalImage.naturalWidth} × ${originalImage.naturalHeight} px · ${formatBytes(finalBlob.size)}`;

    downloadBtn.href = protectedUrl;
    downloadBtn.download = "picsafe_protected.png";
    downloadBtn.classList.remove("disabled");
    downloadBtn.setAttribute("aria-disabled", "false");

    formatResult.textContent = selectedFile.type || "알 수 없는 형식";
    dimensionsResult.textContent = `${originalImage.naturalWidth} × ${originalImage.naturalHeight} px`;
    methodResult.textContent = "PNG 변환 + PicSafe 안내 메타데이터 추가";
    hashResult.textContent = hash;

    reportText = [
      "PicSafe 실험 기록",
      `원본 파일명: ${selectedFile.name}`,
      `원본 형식: ${selectedFile.type || "알 수 없음"}`,
      `원본 파일 크기: ${formatBytes(selectedFile.size)}`,
      `이미지 크기: ${originalImage.naturalWidth} × ${originalImage.naturalHeight} px`,
      "처리 방식: PNG 변환 + 안내 메타데이터 추가",
      `SHA-256 (메타데이터 추가 전 PNG): ${hash}`,
      `처리 시각(UTC): ${timestamp}`,
      "주의: 이 처리는 AI 합성 방지 효과를 제공하거나 보장하지 않습니다."
    ].join("\n");

    copyReportBtn.disabled = false;
    setStatus("처리가 완료되었습니다. PNG 파일을 다운로드할 수 있습니다.");
  } catch (error) {
    console.error(error);
    setStatus(`처리 실패: ${error.message}`);
  } finally {
    processBtn.disabled = false;
  }
});

copyReportBtn.addEventListener("click", async () => {
  if (!reportText) return;
  try {
    await navigator.clipboard.writeText(reportText);
    setStatus("실험 기록을 클립보드에 복사했습니다.");
  } catch {
    // Clipboard API가 제한된 환경에서도 기록을 복사할 수 있도록 선택 창을 표시합니다.
    window.prompt("아래 실험 기록을 복사하세요:", reportText);
  }
});
