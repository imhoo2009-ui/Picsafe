# PicSafe — GitHub Pages 프로토타입

## 기능
- 사진 업로드 및 미리 보기
- 브라우저 안에서 PNG로 변환
- PNG에 PicSafe 안내, 처리 시각, SHA-256 식별 정보를 담은 `tEXt` 메타데이터 청크 추가
- 처리본 다운로드
- 실험 기록 복사

## 한계
이 프로젝트는 AI 합성을 방해하지 않으며 딥페이크 방지 효과를 보장하지 않습니다. 메타데이터는 플랫폼에서 제거될 수 있습니다. SHA-256은 파일 식별용 해시이지 보호 코드가 아닙니다. JPG/WEBP 파일은 PNG로 변환되므로 원본 바이트와 메타데이터가 유지되지 않습니다.

## GitHub Pages 배포
1. GitHub에서 새 공개 저장소 `PicSafe`를 만듭니다.
2. `index.html`, `style.css`, `script.js`를 저장소 루트에 업로드합니다.
3. Settings → Pages → Build and deployment에서 `Deploy from a branch`를 선택합니다.
4. Branch `main`, folder `/(root)`를 선택하고 Save를 누릅니다.
5. 잠시 기다린 뒤 Pages 화면에 표시된 사이트 링크를 엽니다.

## 로컬 실행
파일 3개를 같은 폴더에 두고 `index.html`을 브라우저에서 열 수 있습니다. SHA-256 기능은 보안 컨텍스트가 필요한 브라우저가 있으므로, GitHub Pages의 HTTPS 주소에서 사용하는 것을 권장합니다.
